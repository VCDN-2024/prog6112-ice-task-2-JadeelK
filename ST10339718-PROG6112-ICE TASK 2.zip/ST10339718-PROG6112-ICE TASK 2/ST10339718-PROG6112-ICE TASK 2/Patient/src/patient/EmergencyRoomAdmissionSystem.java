
package patient;

import java.util.ArrayList;
import java.util.Scanner;

public class EmergencyRoomAdmissionSystem {
    private final ArrayList<Patient> patients;

    public EmergencyRoomAdmissionSystem() {
        patients = new ArrayList<>();
        patients.add(new FemalePatient("Samantha", 16));
        patients.add(new MalePatient("Johnny", 19, true));
        patients.add(new MalePatient("Sam", 18, false));
        patients.add(new MalePatient("Ricky", 20, true));
        patients.add(new MalePatient("Brock", 16, false));
        patients.add(new FemalePatient("Julia", 15));
        patients.add(new FemalePatient("Tricksi", 20));
        patients.add(new FemalePatient("Stephanie", 21));
    }

    public void login() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter username: Admin ");
        String username = scanner.nextLine();
        System.out.print("Enter password: Admin ");
        String password = scanner.nextLine();

        if (username.equals("Admin") && password.equals("Admin")) {
            System.out.println("Login successful!");
            searchPatient();
        } else {
            System.out.println("Invalid username or password. Please try again.");
            login();
        }
    }

    public void searchPatient() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter patient name: ");
        String name = scanner.nextLine();

        for (Patient patient : patients) {
            if (patient.name.equals(name)) {
                if (patient instanceof FemalePatient) {
                    FemalePatient femalePatient = (FemalePatient) patient;
                    System.out.println("Patient found: " + patient.name + ", Age: " + patient.age + ", Gender: " + patient.gender);
                    System.out.println("Eligibility: " + femalePatient.isEligible());
                    System.out.println("Treatment Location: " + femalePatient.getTreatmentLocation());
                } else if (patient instanceof MalePatient) {
                    MalePatient malePatient = (MalePatient) patient;
                    System.out.println("Patient found: " + patient.name + ", Age: " + patient.age + ", Gender: " + patient.gender);
                    System.out.println("Eligibility: " + malePatient.isEligible());
                    System.out.println("Treatment Location: " + malePatient.getTreatmentLocation());
                }
                return;
            }
        }
        System.out.println("Patient not found. Please try again.");
        searchPatient();
    }

    public void displayPatients() {
        for (Patient patient : patients) {
            if (patient instanceof FemalePatient) {
                FemalePatient femalePatient = (FemalePatient) patient;
                System.out.println("Patient: " + patient.name + ", Age: " + patient.age + ", Gender: " + patient.gender);
                System.out.println("Eligibility: " + femalePatient.isEligible());
                System.out.println("Treatment Location: " + femalePatient.getTreatmentLocation());
            } else if (patient instanceof MalePatient) {
                MalePatient malePatient = (MalePatient) patient;
                System.out.println("Patient: " + patient.name + ", Age: " + patient.age + ", Gender: " + patient.gender);
                System.out.println("Eligibility: " + malePatient.isEligible());
                System.out.println("Treatment Location: " + malePatient.getTreatmentLocation());
            }
        }
    }

    public static void main(String[] args) {
        EmergencyRoomAdmissionSystem system = new EmergencyRoomAdmissionSystem();
        system.login();
        system.displayPatients();
    }
}



    



